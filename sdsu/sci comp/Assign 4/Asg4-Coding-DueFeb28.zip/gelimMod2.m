function x=gelimMod2(A,b)
  % solve Ax = b via guassian elimimination in mod 2 arithmetic
  
  x = zeros(size(b));  % allocate space for x  (currently all 0)


end