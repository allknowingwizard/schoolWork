use Census;

INSERT INTO state
VALUE ('Alabama'); 
INSERT INTO state
VALUE ('Alaska');
INSERT INTO state
VALUE ( 'Arizona');
INSERT INTO state
VALUE ('Arkansas'); 
INSERT INTO state
VALUE ('California'); 

INSERT INTO state
VALUE ('Colorado'); 
INSERT INTO state
VALUE ('Connecticut');
INSERT INTO state
VALUE ( 'Delaware'); 
INSERT INTO state
VALUE ('Florida');
INSERT INTO state
VALUE ('Georgia'); 

INSERT INTO state
VALUE ('Hawaii'); 
INSERT INTO state
VALUE ('Idaho');
INSERT INTO state
VALUE ('Illinois');
INSERT INTO state
VALUE ( 'Indiana'); 
INSERT INTO state
VALUE ('Iowa');
INSERT INTO state
VALUE ('Kansas');

INSERT INTO state
VALUE ('Kentucky');
INSERT INTO state
VALUE ( 'Louisiana'); 
INSERT INTO state
VALUE ('Maine');
INSERT INTO state
VALUE ('Maryland');
INSERT INTO state
VALUE ('Massachusetts'); 

INSERT INTO state
VALUE ('Michigan');
INSERT INTO state
VALUE ('Minnesota');
INSERT INTO state
VALUE ('Mississippi'); 
INSERT INTO state
VALUE ('Missouri'); 
INSERT INTO state
VALUE ('Montana');

INSERT INTO state
VALUE ('Nebraska'); 
INSERT INTO state
VALUE ('Nevada');
INSERT INTO state
VALUE ( 'New Hampshire'); 
INSERT INTO state
VALUE ('New Jersey');
INSERT INTO state
VALUE ('New Mexico');

INSERT INTO state
VALUE ('New York');
INSERT INTO state
VALUE ('North Carolina');
INSERT INTO state
VALUE ( 'North Dakota');
INSERT INTO state
VALUE ( 'Ohio');
INSERT INTO state
VALUE ('Oklahoma');

INSERT INTO state
VALUE ('Oregon');
INSERT INTO state
VALUE ( 'Pennsylvania');
INSERT INTO state
VALUE ( 'Rhode Island');
INSERT INTO state
VALUE ('South Carolina'); 

INSERT INTO state
VALUE ('South Dakota'); 
INSERT INTO state
VALUE ('Tennessee'); 
INSERT INTO state
VALUE ('Texas'); 
INSERT INTO state
VALUE ('Utah');
INSERT INTO state
VALUE ('Vermont');
INSERT INTO state
VALUE ('Virginia');

INSERT INTO state
VALUE ('Washington'); 
INSERT INTO state
VALUE ('West Virginia'); 
INSERT INTO state
VALUE ('Wisconsin'); 
INSERT INTO state
VALUE ('Wyoming');
